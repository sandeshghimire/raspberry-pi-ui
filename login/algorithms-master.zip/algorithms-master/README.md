Algorithm 

  sudo apt-get install build-essential
