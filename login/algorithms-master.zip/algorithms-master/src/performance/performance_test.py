import timeit 
import os
import sys

class preformanceTest:
    __init__
    





if __name__ == '__main__':
    import timeit
    print(timeit.timeit("test()", setup="from __main__ import test"))