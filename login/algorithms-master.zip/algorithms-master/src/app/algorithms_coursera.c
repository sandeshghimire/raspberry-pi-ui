/*
 ============================================================================
 Name        : algorithms_coursera.cpp
 Author      : Sandesh J. Ghimire
 Version     :
 Copyright   : GPL2
 Description : Hello World in C,
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char ** argv)
{

	return 0;
}
