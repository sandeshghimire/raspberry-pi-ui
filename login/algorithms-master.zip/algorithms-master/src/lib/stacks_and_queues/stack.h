/*!
 * \file stach.h
 *
 */

#ifndef STACK_H
#define STACK_H

#include <types.h>

/*!
 * \enum
 */
typedef enum
{
	NO_ERROR = 1,
	STACK_HEAD_NOT_NULL
};

typedef struct stack_node{
	struct stack_node * next;
	int data;

}stack_node_type;

int init_stack(const stack_node_type * const head, const int size );
int is_empty(stack_node_type * ptr);
int is_stack_full(stack_node_type * ptr);
int pop(stack_node_type * ptr);
int push(stack_node_type * ptr);

#endif /*STACK_H*/
