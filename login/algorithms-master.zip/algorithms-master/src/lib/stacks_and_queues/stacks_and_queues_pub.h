#ifndef STACKS_AND_QUEUES_PUB_H
#define STACKS_AND_QUEUES_PUB_H

#include "linked_list.h"
#include "queue.h"
#include "stack.h"

extern void stacks_and_queues_hello_world(void);

#endif /*STACKS_AND_QUEUES_PUB_H*/
