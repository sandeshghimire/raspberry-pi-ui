#include "stack.h"

int init_stack(const stack_node_type * const head, const int size )
{
	int err = -1;



	return err;
}
int is_empty(stack_node_type * ptr)
{
	int err = -1;
	return err;
}
int is_full(stack_node_type * ptr)
{
	int err = -1;
	return err;
}
int pop(stack_node_type * ptr)
{
	int err = -1;
	return err;
}
int push(stack_node_type * ptr)
{
	int err = -1;
	return err;
}


