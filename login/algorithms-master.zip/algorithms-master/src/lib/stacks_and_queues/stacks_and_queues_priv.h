#ifndef STACKS_AND_QUEUES_PRIV_H
#define STACKS_AND_QUEUES_PRIV_H


void stacks_and_queues_hello_world(void);



#endif /*STACKS_AND_QUEUES_PRIV_H*/
