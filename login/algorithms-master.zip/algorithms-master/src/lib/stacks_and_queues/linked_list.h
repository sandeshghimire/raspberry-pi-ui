#ifndef LINKED_LIST_H
#define LINKED_LIST_H

#include <types.h>

typedef struct node_type
{
    uint32_t data;
    struct node_type * next;
    struct node_type * prev;

}list_node;

typedef enum
{
  LIST_EMPTY,
  LIST_NOT_EMPTY,
  LIST_STATUS_UNKNOWN
}list_status;


typedef enum
{
  NO_ERR,
  ERR,
  MEM_ALLO_ERR,
  INDEX_OUT_OF_BOUND_ERR,
  LIST_EMPTY_ERR


}list_err;


#endif /*LINKED_LIST_H*/
