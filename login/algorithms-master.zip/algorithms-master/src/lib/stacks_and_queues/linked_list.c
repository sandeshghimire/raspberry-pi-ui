#include <stdio.h>
#include <stdlib.h>

#include "linked_list.h"

list_err init_linked_list(list_node * head);
list_err cleanup_linked_list(list_node * head);
list_err linked_list_add_element_front(list_node * head, uint32_t data);
list_err linked_list_add_element_back(list_node * head, uint32_t data);
list_err linked_list_add_element_by_index(list_node * head, uint32_t data, uint32_t index);
list_err linked_list_remove_element_front(list_node * node);
list_err linked_list_remove_element_back(list_node * node);
list_err linked_list_remove_element_by_index(list_node * node, uint32_t index);
list_status is_list_empty(list_node * head);
uint32_t  size_of_list(list_node * head);
list_err linked_list_sort_acending(list_node * node);
list_err linked_list_sort_decending(list_node * node);
list_err linked_list_search(list_node * node, uint32_t item, uint32_t * data);
list_status linked_list_print(list_node * head);

/*******************************************************************************
 * \function: init_linked_list
 * \input
 * \output
 *
 * \description: Process entry
 *
 ******************************************************************************/
list_err init_linked_list(list_node * head)
{
   list_err err = NO_ERR;
   if (head != NULL)
   {
      head = NULL;
   }
   return err;
}
/*******************************************************************************
 * \function: init_linked_list
 * \input
 * \output
 *
 * \description: Process entry
 *
 ******************************************************************************/
list_err linked_list_add_element_front(list_node * head, uint32_t data)
{
   list_err err = NO_ERR;
   list_node * cur;

   cur = (list_node *) malloc(sizeof(list_node));
   cur->data = data;
   if (cur == NULL)
   {
      err = MEM_ALLO_ERR;
   }
   else
   {
      if (head->next == NULL)
      {
         cur->next = NULL;
         head->next = cur;

      }
      else
      {
         cur->next = head->next;
         head->next = cur;

      }
   }
   return err;
}

list_err cleanup_linked_list(list_node * head)
{
   list_node * cur = head->next;
   list_node * tail;
   uint32_t index = 0;
   while (cur != NULL)
   {
      tail = cur;
      free(tail);
      cur = cur->next;
      index++;
   }
   head->next = NULL;
   list_err err = NO_ERR;
   return err;
}

list_err linked_list_add_element_back(list_node * head, uint32_t data)
{
   list_err err = NO_ERR;
   list_node * cur;
   list_node * tail = head;

   cur = (list_node *) malloc(sizeof(list_node));
   cur->data = data;
   if (cur == NULL)
   {
      err = MEM_ALLO_ERR;
   }
   else
   {
      if (head->next == NULL)
      {
         head->next = cur;
         cur->next = NULL;
      }
      else
      {
         while (tail->next != NULL)
         {
            tail = tail->next;
         }
         tail->next = cur;
         cur->next = NULL;

      }
   }
   return err;
}
list_err linked_list_add_element_by_index(list_node * head, uint32_t data, uint32_t index)
{
   list_err err = NO_ERR;
   list_node * cur = head;
   list_node * node ;
   uint32_t l_index = 0;

   if (index > size_of_list(head))
   {
      err = INDEX_OUT_OF_BOUND_ERR;
   }
   else
   {
      node = (list_node *) malloc(sizeof(list_node));
      node->data = data;
      if (node == NULL)
      {
         err = MEM_ALLO_ERR;
      }
      else
      {

         for (l_index = 0; l_index < index; l_index++)
         {
            cur = cur->next;
         }

         if(head->next == NULL )
         {
            head->next = node;
            node->next = NULL;
         }
         else
         {
            node->next = cur->next;
            cur->next = node;
         }
      }
   }
   return err;
}
list_err linked_list_remove_element_front(list_node * head)
{
   list_err err = NO_ERR;
   list_node * cur = head->next;
   if(LIST_EMPTY == is_list_empty(head))
   {
      printf("list empty  \n");
      err = LIST_EMPTY_ERR;
   }
   else
   {
      head->next = cur->next;
      free(cur);
   }

   return err;
}
list_err linked_list_remove_element_back(list_node * head)
{
   list_err err = NO_ERR;
   list_node * cur = head;
   list_node * tail = NULL;

   if(LIST_EMPTY == is_list_empty(head))
   {
      printf("list empty  \n");
      err = LIST_EMPTY_ERR;
   }
   else
   {
      while(cur->next->next != NULL)
      {
         cur = cur->next;
      }
      tail = cur->next;
      cur->next = NULL;
      free(tail);
   }

   return err;
}
list_err linked_list_remove_element_by_index(list_node * head, uint32_t index)
{
   list_err err = NO_ERR;
   list_node * cur = head;
   list_node * tail = NULL;
   uint32_t l_index = 0;

   if(index >  size_of_list(head))
   {
      err = INDEX_OUT_OF_BOUND_ERR;
   }
   else
   {
      for(l_index = 0; l_index < index; l_index++)
      {
         cur = cur->next;
      }

      tail = cur->next;

      if(tail->next ==  NULL)
      {
         free(tail);
      }
      else
      {
          tail = cur;
          tail->next = tail->next->next;
          printf("list not empty \n");
      }

   }

   return err;
}
list_status is_list_empty(list_node * head)
{
   list_status status = LIST_STATUS_UNKNOWN;
   if (head->next == NULL)
   {
      status = LIST_EMPTY;
   }
   else
   {
      status = LIST_NOT_EMPTY;
   }
   return status;
}

uint32_t size_of_list(list_node * head)
{
   uint32_t size = 0;
   list_node * cur = head;
   if (cur->next == NULL)
   {
      size = 0;
   }
   else
   {
      while (cur->next)
      {
         size++;
         cur = cur->next;
      }
   }
   return size;
}

list_err linked_list_sort_acending(list_node * head)
{
   list_err err = NO_ERR;
   list_node * cur = head;
   if(LIST_EMPTY == is_list_empty(head))
   {
      printf("list empty  \n");
      err = LIST_EMPTY_ERR;
   }
   else
   {
      printf("list not empty \n");
      head = head->next;
      free(cur);

   }

   return err;
}
list_err linked_list_sort_decending(list_node * head)
{
   return NO_ERR;
}
list_err linked_list_search(list_node * head, uint32_t item, uint32_t * data)
{
   return NO_ERR;
}
list_status linked_list_print(list_node * head)
{
   list_status status = LIST_STATUS_UNKNOWN;
   list_node * cur = head;
   uint32_t index = 0;

   if (cur->next == NULL)
   {
      status = LIST_EMPTY;
   }
   else
   {
      while (cur->next != NULL)
      {
         cur = cur->next;
         printf("%d \t",  cur->data);
      }
      printf("\n");
      status = LIST_NOT_EMPTY;
   }
   return status;
}

