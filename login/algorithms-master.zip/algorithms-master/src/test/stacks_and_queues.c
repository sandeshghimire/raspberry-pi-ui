/*
 ============================================================================
 Name        : algorithms_coursera.cpp
 Author      : Sandesh J. Ghimire
 Version     :
 Copyright   : GPL2
 Description : Hello World in C,
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>

#include <types.h>

#include "stacks_and_queues_pub.h"

int main(int argc, char ** argv)
{
   list_err err = NO_ERR;
   list_node * head;
   list_status status = LIST_STATUS_UNKNOWN;
   uint32_t size;

   err = init_linked_list(&head);
   if (err != NO_ERR)
   {
      printf("Error Initializing list \n");
      return 0;
   }
   else
   {
      size = size_of_list(&head);
      printf("the size of the list is %u \n", size);
      status = linked_list_print(&head);

      err = linked_list_add_element_front(&head, 8);
      err = linked_list_add_element_front(&head, 1);
      err = linked_list_add_element_front(&head, 2);
      err = linked_list_add_element_front(&head, 3);
      err = linked_list_add_element_front(&head, 4);
      err = linked_list_add_element_front(&head, 5);
      err = linked_list_add_element_front(&head, 6);
      err = linked_list_add_element_front(&head, 7);

      err = linked_list_add_element_back(&head, 80);
      err = linked_list_add_element_back(&head, 10);
      err = linked_list_add_element_back(&head, 20);
      err = linked_list_add_element_back(&head, 30);
      err = linked_list_add_element_back(&head, 40);
      err = linked_list_add_element_back(&head, 50);
      err = linked_list_add_element_back(&head, 60);
      err = linked_list_add_element_back(&head, 70);

      status = linked_list_print(&head);
      size = size_of_list(&head);
      printf("the size of the list is %u \n", size);

      printf("\n\n======================================\n\n");
      linked_list_add_element_by_index(&head, 500, 0);
      status = linked_list_print(&head);
      size = size_of_list(&head);
      printf("the size of the list is %u \n", size);

      printf("\n\n======================================\n\n");
      linked_list_add_element_by_index(&head, 300, 0);
      status = linked_list_print(&head);
      size = size_of_list(&head);
      printf("the size of the list is %u \n", size);

      printf("\n\n======================================\n\n");
      ;
      linked_list_add_element_by_index(&head, 600, 2);
      status = linked_list_print(&head);
      size = size_of_list(&head);
      printf("the size of the list is %u \n", size);
      printf("\n\n======================================\n\n");

      linked_list_add_element_by_index(&head, 900, 1);
      status = linked_list_print(&head);
      size = size_of_list(&head);
      printf("the size of the list is %u \n", size);
      printf("\n\n======================================\n\n");

      linked_list_add_element_by_index(&head, 900, 8);
      status = linked_list_print(&head);
      size = size_of_list(&head);
      printf("the size of the list is %u \n", size);
      printf("\n\n======================================\n\n");

      printf("Removing List from the top \n");
      linked_list_remove_element_front(&head);
      status = linked_list_print(&head);
      size = size_of_list(&head);
      printf("the size of the list is %u \n", size);
      printf("\n\n======================================\n\n");

      printf("Removing List from the end \n");
      linked_list_remove_element_back(&head);
      status = linked_list_print(&head);
      size = size_of_list(&head);
      printf("the size of the list is %u \n", size);
      printf("\n\n======================================\n\n");

      printf("Removing List by index \n");
      linked_list_remove_element_by_index(&head, 5);
      status = linked_list_print(&head);
      size = size_of_list(&head);
      printf("the size of the list is %u \n", size);
      printf("\n\n======================================\n\n");

      cleanup_linked_list(&head);

      size = size_of_list(&head);
      printf("the size of the list is %u \n", size);

   }

   return 0;
}
