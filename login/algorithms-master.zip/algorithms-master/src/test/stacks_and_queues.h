#ifndef STACKS_AND_QUEUES_H
#define STACKS_AND_QUEUES_H

#include <stacks_and_queues_pub.h>

#endif /*STACKS_AND_QUEUES_H*/
